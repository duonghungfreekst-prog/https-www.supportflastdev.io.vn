# ⏰ HƯỚNG DẪN CÀI ĐẶT & SỬ DỤNG: ĐỒNG HỒ BÁO THỨC v1.0.1 (ANDROID)

> **Phiên bản:** v1.0.1 (Build 2)  
> **Nền tảng:** Android 8.0+ (Tối ưu hoàn hảo cho Android 13, 14, 15)  
> **Công nghệ:** Flutter Material 3, Dark OLED, Local Notifications, Offline 100%

---

## 🚀 1. HƯỚNG DẪN CÀI ĐẶT FILE APK TRÊN ĐIỆN THOẠI

1. Tải file **`DongHoBaoThuc_v1.0.1_release.apk`** về điện thoại của bạn.
2. Mở file APK vừa tải về từ thư mục **Download / Trình quản lý tệp**.
3. Nếu hệ thống thông báo *"Cài đặt ứng dụng từ nguồn không xác định"*, chọn **Cài đặt -> Bật cho phép nguồn này**.
4. Bấm **Cài đặt (Install)** và chờ vài giây để hoàn tất.

---

## 🔔 2. CÁC TÍNH NĂNG CHÍNH

### 2.1 Tab Báo Thức (Alarm)
- **Tạo báo thức:** Nhấn biểu tượng dấu cộng `+` màu cam để thiết lập thời gian báo thức.
- **Lặp lại:** Tùy chọn lặp lại các ngày trong tuần (T2 - T6 cho ngày làm việc, T7 - CN cho ngày nghỉ).
- **Nhạc chuông:** Chọn 1 trong 12 giai điệu chuông độc quyền từ du dương đến vang to đánh thức sâu.
- **Tùy chỉnh âm lượng & Chống tắt nhầm:** Hỗ trợ tính năng nhắc lại sau 5, 10 phút (Snooze).

### 2.2 Tab Giờ Quốc Tế (World Clock)
- Theo dõi thời gian thực tại các thủ đô và trung tâm tài chính lớn trên thế giới: **Tokyo, London, New York, Paris, Seoul, Singapore, Sydney...**
- Tự động tính toán số giờ chênh lệch sớm hơn hoặc muộn hơn so với giờ Hà Nội (GMT+7).

### 2.3 Tab Bấm Giờ Thể Thao (Stopwatch)
- Đo lường thời gian với độ chính xác đến **1/100 giây**.
- Ghi nhận nhiều vòng chạy (Lap times) với chỉ số hiển thị vòng nhanh nhất (Best Lap).

### 2.4 Tab Đếm Ngược (Timer)
- Hẹn giờ cho các hoạt động nấu ăn, tập gym, thiền, đọc sách hoặc làm việc theo phương pháp Pomodoro.
- Tự động phát âm thanh cảnh báo khi đồng hồ về 0.

---

## 🛡 3. BẢO MẬT & CẤP QUYỀN CHẠY NGẦM CHUẨN XÁC 100%

Để đảm bảo hệ điều hành Android (nhất là Xiaomi, Samsung, Oppo, Vivo) không tự động tắt ngầm ứng dụng:

1. **Cấp quyền Báo thức chính xác (Exact Alarms):**
   - Vào **Cài đặt máy** -> **Ứng dụng** -> **Đồng Hồ Báo Thức** -> **Báo thức & nhắc nhở** -> Chọn **Cho phép**.
2. **Tắt tối ưu hóa pin:**
   - Vào **Cài đặt** -> **Pin** -> **Tối ưu hóa pin** -> Tìm **Đồng Hồ Báo Thức** -> Chọn **Không tối ưu hóa (Không hạn chế)**.
3. **Bật Tự khởi chạy (Autostart):**
   - Bật công tắc **Tự khởi động** để khi khởi động lại máy, lịch hẹn giờ vẫn được bảo toàn trọn vẹn.

---
*Phát triển bởi Dương Mạnh Hùng (DMH Tech) — Nền tảng SupportFlast Hub.*
