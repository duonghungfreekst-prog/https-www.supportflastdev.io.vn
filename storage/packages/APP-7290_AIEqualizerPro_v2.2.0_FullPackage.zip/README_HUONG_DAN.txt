﻿================================================================================
AI EQUALIZER PRO & AUDIO PROCESSOR v2.2.0 (MAXIMUM ENHANCED EDITION)
Phát hành chính thức trên Cổng Đăng Tải SupportFlast Hub: https://supportflastdev.io.vn
Mã Định Danh: APP-7290
Tác giả: Dương Mạnh Hùng (DMH Tech & Antigravity)
================================================================================

1. NỘI DUNG GÓI CÀI ĐẶT:
   - AIEqualizerPro-v2.2.apk: Ứng dụng Android chạy nền tối ưu cao, tự động lọc toàn bộ âm thanh hệ thống.
   - web/: Giao diện Web Audio HUD 10 băng tần, visualizer real-time và 4 hiệu ứng DSP.

2. HƯỚNG DẪN CÀI ĐẶT ANDROID:
   - Cài đặt trực tiếp file AIEqualizerPro-v2.2.apk lên điện thoại (Android 8.0+).
   - Mở app: Hệ thống tự động kích hoạt bộ lọc âm thanh toàn máy ngay lập tức.
   - Nhấn '⚡ TỰ ĐỘNG LỌC TOÀN BỘ ỨNG DỤNG (1 CHẠM)' để cấp quyền Micro và Thông báo trong 1 giây mà KHÔNG CẦN CẮM MÁY TÍNH.

3. HƯỚNG DẪN SỬ DỤNG WEB HUD:
   - Mở file web/index.html bằng trình duyệt Chrome, Edge, Cốc Cốc hoặc Firefox.
   - Hỗ trợ tải nhạc MP3/FLAC/WAV, phát Synth Ambient, thu Micro hoặc Lọc âm thanh tab trình duyệt.
