================================================================================
AI EQUALIZER PRO & AUDIO PROCESSOR v2.2.0
Hệ thống Bộ Lọc Âm Thanh Chuyên Nghiệp 10 Băng Tần & 3D Spatial Audio
Phát hành trên Cổng Phân Phối SupportFlast (supportflastdev.io.vn)
Mã API Bản Quyền Kích Hoạt: sf_live_db1ead71775e5129ed0533574b8ca7ae317791b7e77d9290
================================================================================

1. BỘ CÀI ĐẶT ANDROID:
   - Tệp tin: AIEqualizerPro-v2.2.apk
   - Yêu cầu: Android 8.0 trở lên (Tối ưu cho Android 13, 14, 15)
   - Cài đặt: Mở file APK trên điện thoại -> Chọn Cho phép nguồn không xác định -> Cài đặt.

2. PHIÊN BẢN WEB AUDIO HUD TRỰC TIẾP:
   - Thư mục 'web/': Mở file 'index.html' bằng trình duyệt bất kỳ (Chrome, Edge, Cốc Cốc, Firefox).
   - Hỗ trợ đầy đủ: Tải file nhạc, Synth Ambient, Bắt Mic và Lọc âm hệ thống trực tiếp (Share Audio).

3. ĐỒNG BỘ ĐÁM MÂY VỚI SUPPORTFLAST HUB:
   - Mã API: sf_live_db1ead71775e5129ed0533574b8ca7ae317791b7e77d9290
   - Endpoint: https://supportflastdev.io.vn/api/apps
   - Trạng thái: Active / Đã xác thực bảo mật chuẩn OWASP & Constant-Time Security.
================================================================================
