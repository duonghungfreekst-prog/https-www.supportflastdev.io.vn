-- ==========================================================
-- Mau09 Database Schema (PostgreSQL & Standard SQL)
-- Hệ thống Quản lý & Báo cáo Chi phí BHYT Mẫu 09
-- Tuân thủ Quy chuẩn Polyglot & Bảo mật Antigravity
-- ==========================================================

CREATE TABLE IF NOT EXISTS patients (
    patient_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    date_of_birth DATE,
    gender VARCHAR(10),
    contact_number VARCHAR(20),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS medical_history (
    record_id SERIAL PRIMARY KEY,
    patient_id INT NOT NULL REFERENCES patients(patient_id) ON DELETE CASCADE,
    visit_date DATE NOT NULL,
    diagnosis TEXT,
    treatment TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Chỉ mục tối ưu hóa hiệu năng truy vấn cho 30 ngày gần nhất
CREATE INDEX IF NOT EXISTS idx_patients_name ON patients(last_name, first_name);
CREATE INDEX IF NOT EXISTS idx_medical_visit_date ON medical_history(visit_date);
CREATE INDEX IF NOT EXISTS idx_medical_patient ON medical_history(patient_id);
