@echo off
title Cai Dat Phim Tat Mau09 (Desktop Shortcut)
cd /d "%~dp0"

echo ========================================================
echo   TAO PHIM TAT KHOI DONG MAU09 TREN MAN HINH (DESKTOP)
echo ========================================================
echo.

powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\Mau09 - Giam Dinh BHYT.lnk'); $s.TargetPath = '%~dp0KhoiDong_Mau09.bat'; $s.WorkingDirectory = '%~dp0'; if (Test-Path '%~dp0Mau09.exe') { $s.IconLocation = '%~dp0Mau09.exe,0' }; $s.Save()"

echo Da tao Shortcut thanh cong tren Desktop!
echo Nguoi dung co the nhan dup vao bieu tuong 'Mau09 - Giam Dinh BHYT' ngoai man hinh de su dung.
echo.
pause
