# CẨM NANG HƯỚNG DẪN SỬ DỤNG HỆ THỐNG ĐỐI SOÁT & KÝ SỐ BHYT MẪU 09

> **Hệ thống Quản lý, Thẩm định & Ký số Hồ sơ Khám Chữa bệnh BHYT Mẫu 09 (Mau09)**
> Tiêu chuẩn kỹ thuật: Quyết định 130/QĐ-BYT, Quyết định 4750/QĐ-BYT & Quyết định 4210/QĐ-BYT của Bộ Y tế.
> Kiến trúc bảo mật Antigravity Polyglot: C# WPF UI • Go Engine Gateway • Python AI Analytics • Rust Security Core.

---

## Tổng Quan & Căn Cứ Pháp Lý
Hệ thống **Mau09** là giải pháp chuyên sâu phục vụ công tác đối soát chi phí, thẩm định tính toàn vẹn dữ liệu y tế và ký số điện tử cho hồ sơ điều chỉnh giám định BHYT (Mẫu 09/BH - HOSO_DIEUCHINH_GD).

- **Quyết định 130/QĐ-BYT**: Quy định chuẩn và định dạng dữ liệu đầu ra phục vụ quản lý, giám định, thanh toán chi phí KCB BHYT.
- **Quyết định 4750/QĐ-BYT**: Quy định chuẩn định dạng gói hồ sơ bệnh án điện tử và điều chỉnh chi phí KCB BHYT liên thông.
- **Kiến trúc Antigravity Polyglot 4 tầng**:
  - `mau09_ui`: Giao diện C# WPF giao diện phẳng, phân khoang màu y tế chuẩn mực, tối ưu hóa ảo hóa danh sách 60 FPS.
  - `mau09_engine`: Cổng điều phối Gateway đa luồng bằng Go (Golang) xử lý đồng thời, quản lý bộ nhớ đệm cache và xác thực API.
  - `mau09_ai`: Module Python phân tích dữ liệu, True Streaming xử lý khối lượng lớn, tính toán tiền tệ Decimal chuẩn kế toán.
  - `mau09_core`: Lõi bảo mật Rust biên dịch FFI/cdylib thực thi mã hóa AES-256-GCM an toàn và kiểm tra chữ ký số phần cứng.

---

## Cấu Hình Kết Nối Cơ Sở Dữ Liệu HIS
Phần mềm kết nối trực tiếp với hệ quản trị CSDL của hệ thống Quản lý Bệnh viện / Phòng khám (HIS) để đồng bộ dữ liệu bệnh nhân và bảng kê chi phí:

- **Bước 1**: Nhấp vào thanh tiêu đề **"Cấu Hình Kết Nối CSDL"** tại thanh công cụ bên trái giao diện.
- **Bước 2**: Khai báo các tham số máy chủ:
  - **Máy chủ SQL Server**: Địa chỉ IP hoặc tên máy chủ (Ví dụ: `192.168.1.100` hoặc `.\SQLEXPRESS`).
  - **Tên Database (CSDL)**: Tên cơ sở dữ liệu HIS (Ví dụ: `EMR_PHUTHAI`, `HIS_HOSPITAL`).
  - **Tài khoản / Mật khẩu**: Tài khoản truy cập SQL Server có quyền đọc bảng dữ liệu KCB.
- **Bước 3 - Bảo mật mật khẩu**:
  - Tích chọn **"Lưu cấu hình & mật khẩu (DPAPI)"**: Toàn bộ mật khẩu được mã hóa an toàn bằng công nghệ Windows DPAPI (`DataProtectionScope.CurrentUser`). Mật khẩu không bao giờ lưu dưới dạng văn bản thô (plaintext).
- **Bước 4 - Xác thực bảo mật TLS**:
  - Tùy chọn **"Tin cậy chứng chỉ máy chủ (Lab/Self-Signed)"**: Mặc định luôn **TẮT** để chống tấn công nghe lén (Man-In-The-Middle). Chỉ bật khi thử nghiệm trên mạng Lab nội bộ dùng chứng chỉ tự ký.
- **Bước 5**: Nhấn **"Kiểm Tra Kết Nối"**. Khi nhận thông báo thành công, hệ thống đã sẵn sàng truy vấn dữ liệu.

---

## Thiết Lập Đơn Vị CSKCB & Thư Mục Xuất XML
Đảm bảo mã định danh đơn vị trên file XML trùng khớp 100% với tài khoản đăng ký trên Cổng Tiếp Nhận Giám Định BHYT:

- **Mã CSKCB Đơn Vị**: Nhập mã định danh 5 ký tự do Bộ Y tế và BHXH Việt Nam cấp (Ví dụ: `19926` cho Cơ sở y tế).
- **Tên CSKCB**: Tên đầy đủ của cơ sở khám chữa bệnh.
- **Thư mục lưu file XML Mẫu 09**: Đường dẫn thư mục lưu trữ file XML sau khi xuất và ký số (Mặc định: `F:\tools 09\Output_XML`).
- Nhấn **"Lưu Cấu Hình Đơn Vị & Ký Số"** để áp dụng vĩnh viễn cấu hình.

---

## Cấu Hình & Tích Hợp Chữ Ký Số USB Token (QĐ 130)
Hệ thống hỗ trợ tất cả các loại USB Token chứng thư số đạt chuẩn của các nhà cung cấp CA tại Việt Nam (Viettel-CA, VNPT-CA, FPT-CA, BKAV-CA, CA2, MISA-CA...):

- **Bước 1**: Cắm thiết bị USB Token vào cổng USB của máy tính.
- **Bước 2**: Nhấn nút **"Quét Token"** hoặc **"Chọn Từ Windows"**.
- **Bước 3 - Nhận diện phần cứng thông minh**:
  - **Chấm xanh lá cây (🟢)**: Chứng thư số nằm trên phần cứng USB Token an toàn (Hardware Token - PKCS#11 / CSP). Khuyến nghị sử dụng cho KCB BHYT.
  - **Chấm vàng (🟡)**: Chứng thư số phần mềm (Software Certificate).
- **Bước 4**: Kiểm tra thông tin hiển thị tại ô thông tin: Tên đơn vị, Nhà cung cấp (Issuer), Số Serial, Hạn sử dụng chứng thư.

---

## Tìm Kiếm, Lọc & Đối Soát Hồ Sơ Bệnh Nhân BHYT
Hỗ trợ lọc dữ liệu theo chu kỳ thanh quyết toán và tìm kiếm tức thì:

- **Bộ lọc thời gian**: Chọn khoảng thời gian quét:
  - `15 ngày gần nhất`
  - `30 ngày gần nhất` (mặc định)
  - `60 ngày gần nhất`
  - `Tất cả dữ liệu`
- Nhấn **"TÌM KIẾM BỆNH NHÂN BHYT"** để nạp danh sách vào bảng.
- **Tìm kiếm bệnh nhân**: Nhập Mã bệnh nhân, Họ tên hoặc 10/15 số thẻ BHYT vào ô tìm kiếm để lọc ngay tức thì.
- Khi nhấp chọn bệnh nhân, thẻ **"HỒ SƠ BỆNH NHÂN ĐANG CHỌN"** ở góc trên bên phải sẽ hiển thị nổi bật tên bệnh nhân và tải dữ liệu lên các bảng chi tiết.

---

## Thẩm Định Tính Toàn Vẹn Dữ Liệu Y Tế (Validator)
Module `MedicalRecordValidator` tự động rà soát, đối chiếu dữ liệu trước khi xuất file nhằm ngăn ngừa 100% tình trạng hồ sơ bị Cổng Giám định BHYT từ chối:

- **Thẩm định mã đối tượng thẻ BHYT**: Kiểm tra đúng 43 mã đối tượng hợp lệ theo quy chế BHXH (DN, HX, CH, NN, TK, HC, CC, TE, HN, DT...). Chặn đứng các mã thẻ giả mạo hoặc mã test demo.
- **Thẩm định cấu trúc thẻ 15 ký tự**: Kiểm tra mã tỉnh, mã quyền lợi mức hưởng (1, 2, 3, 4, 5) và số định danh sổ BHXH.
- **Thẩm định thời hạn**: Bắt buộc `Giá trị thẻ từ <= Ngày vào <= Giá trị thẻ đến` và `Ngày vào <= Ngày ra`.
- **Thẩm định mã bệnh ICD-10**: Khớp chuẩn biểu thức chính quy mã bệnh quốc tế.
- **Thẩm định cân đối tài chính chi phí**:
  - `Tổng chi phí = Tiền BHYT chi trả + Tiền Người bệnh cùng chi trả + Tiền Nguồn khác`.
  - `Tiền thuốc + Tiền VTYT <= Tổng chi phí`.
  - Tỷ lệ hưởng BHYT phải tương thích với mã quyền lợi trên thẻ BHYT (100%, 95%, 80%).

---

## Bảng Chi Tiết XML Mẫu 09 & Biểu Mẫu Tổng Hợp
Giao diện phân chia thành 3 Tab chức năng trực quan:

- **Tab 1 - BẢNG DỮ LIỆU CHI TIẾT XML (MẪU 09)**:
  - Hiển thị từng dòng chi phí KCB: Nhóm dịch vụ, Tên thuốc/VTYT/DVKT, Số lượng, Đơn giá, Tỷ lệ thanh toán, Thành tiền BHYT, Tiền BN chi trả.
  - Cho phép kiểm tra đối chiếu trực tiếp từng danh mục chi phí.
- **Tab 2 - BIỂU MẪU MẪU 09 (FORM TỔNG HỢP)**:
  - Bố cục theo đúng biểu mẫu bản cứng Mẫu 09/BH ban hành kèm theo quyết định của Bộ Y tế.
  - Tổng hợp nhóm chi phí: Tiền khám, Xét nghiệm, CĐHA, Phẫu thuật/Thủ thuật, Máu, Thuốc, VTYT, Giường bệnh, Vận chuyển.
- **Tab 3 - ĐIỀU CHỈNH CHI PHÍ (MẪU 09)**:
  - Ghi nhận lịch sử và chi tiết các khoản mục cần điều chỉnh: Bảng XML liên quan, STT, Trường thông tin gốc, Giá trị gốc, Trường điều chỉnh, Giá trị điều chỉnh, Lý do điều chỉnh.

---

## Quy Trình Xuất File XML, Ký Số 1-Chạm & Sửa Lỗi CSKCB
- **Mở File XML Có Sẵn**: Nhấn **"📂 MỞ FILE XML HỒ SƠ"** để nạp gói XML từ HIS hoặc Cổng Giám định để kiểm tra đối soát độc lập.
- **Xuất XML Chuẩn Mẫu 09**: Nhấn **"📄 XUẤT XML MẪU 09"**. Hệ thống sử dụng cơ chế `AtomicXmlFileWriter` (ghi qua file đệm `.tmp` rồi đổi tên nguyên tử) ngăn chặn hiện tượng tệp bị hỏng khi mất điện hoặc đầy ổ đĩa.
- **Ký Số XML Bằng USB Token**: Nhấn **"🔏 KÝ SỐ XML"**.
  - Phần mềm gọi lệnh chữ ký số W3C XML-DSig (`Enveloped Signature`), áp dụng thuật toán `RSA-SHA256`, chuẩn hóa C14N (`Canonicalization`).
  - Hộp thoại nhập mã PIN của nhà cấp USB Token xuất hiện. Nhập đúng mã PIN để hoàn tất.
  - Hệ thống tự động xác minh tính toàn vẹn của chữ ký số (`verifySignedXml.CheckSignature`) ngay sau khi ký.
- **Quy Trình 1-Chạm**: Nhấn **"⚡ XUẤT & KÝ SỐ (1-CHẠM)"** để tự động hoàn thành từ khâu thẩm định, đóng gói XML đến ký số chỉ trong 1 thao tác duy nhất.
- **Tiện Ích Khắc Phục Lệch Mã CSKCB**:
  - Nhấn nút **"🔧 SỬA MÃ CSKCB & KÝ LẠI XML"** khi file XML bị lỗi từ chối *"Không khớp mã CSKCB"*.
  - Hệ thống tự động cập nhật lại mã cơ sở về chuẩn đơn vị (ví dụ `19926`), cấu trúc lại thẻ XML và thực hiện ký số lại ngay lập tức.

---

## Cơ Chế Tự Động Cập Nhật Bản Mới Từ Web
Hệ thống tích hợp máy khách tự động kiểm tra phiên bản mới từ cổng phân phối `https://www.supportflastdev.io.vn`:

- Khi có phiên bản mới, thanh thông báo màu vàng sẽ tự động xuất hiện ở đỉnh giao diện: *"Đã có bản phát hành mới cho Mau09 trên Web!"*.
- Nhấn **"📥 TẢI BẢN MỚI NGAY"** để mở liên kết tải gói cập nhật mới nhất.
- Người dùng có thể nhấn **"🔄 KIỂM TRA CẬP NHẬT"** tại thanh trạng thái phía dưới để chủ động kiểm tra bất kỳ lúc nào.

---

## Xử Lý Sự Cố Thường Gặp (FAQ & Troubleshooting)

### 1. Không tìm thấy USB Token trong danh sách
- **Nguyên nhân**: Chưa cắm USB Token, cổng USB tiếp xúc kém hoặc máy tính chưa cài Driver Token Manager của nhà cung cấp.
- **Khắc phục**:
  - Rút Token cắm lại vào cổng USB khác (ưu tiên cổng sau mainboard đối với máy bàn).
  - Cài đặt phần mềm quản lý Token đi kèm (ví dụ: Viettel-CA Token Manager, PKI Token Manager).
  - Nhấn nút **"Quét Token"** hoặc bấm **"Chọn Từ Windows"** trên Mau09.

### 2. Ký số báo lỗi "Mã PIN không đúng hoặc Token bị khóa"
- **Nguyên nhân**: Nhập sai mã PIN quá số lần quy định của nhà cung cấp CA.
- **Khắc phục**: Mở ứng dụng Token Manager kiểm tra số lần còn lại hoặc liên hệ nhà mạng cung cấp chữ ký số để được mở khóa PIN.

### 3. File XML bị Cổng Giám định BHYT từ chối: "Sai cấu trúc XML"
- **Nguyên nhân**: Chỉnh sửa file bằng phần mềm ngoài làm mất thẻ đóng hoặc sai bảng mã ký tự (non UTF-8).
- **Khắc phục**: Sử dụng tính năng **"Xuất XML Mẫu 09"** của Mau09 để tệp được tạo bằng `XmlWriter` chuẩn UTF-8 No BOM và tự động bảo vệ dữ liệu bằng CDATA.
