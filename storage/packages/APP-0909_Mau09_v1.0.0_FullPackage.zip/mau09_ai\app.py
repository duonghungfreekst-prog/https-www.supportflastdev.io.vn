import sys
import json
import logging
from datetime import datetime, timedelta
from http.server import HTTPServer, BaseHTTPRequestHandler

# Thiết lập log tiêu chuẩn
logging.basicConfig(level=logging.INFO, format='%(message)s')

def log_ai(message):
    """Hàm log theo chuẩn [AI]"""
    logging.info(f"[AI] {message}")

def fetch_records(db_cursor, start_date, end_date, batch_size=1000):
    """
    Lấy hồ sơ bệnh nhân sử dụng yield/generator để không nạp toàn bộ dataset vào RAM.
    Quy tắc 7.1: Xử lý dữ liệu theo từng chunk (1000-5000 records).
    """
    log_ai(f"Truy vấn hồ sơ bệnh nhân từ {start_date} đến {end_date} (batch_size={batch_size})")
    
    query = "SELECT * FROM patient_records WHERE treatment_date BETWEEN %s AND %s"
    db_cursor.execute(query, (start_date, end_date))
    
    while True:
        batch = db_cursor.fetchmany(batch_size)
        if not batch:
            break
        yield batch
        del batch  # Quy tắc 7.1: Xóa biến không dùng sau khi xử lý xong để giải phóng bộ nhớ

def process_09_bhyt_form(record):
    """
    Xử lý 1 bản ghi để tạo dữ liệu mẫu 09/BHYT.
    """
    total_cost = float(record.get("total_cost", 0.0) or 0.0)
    return {
        "patient_id": str(record.get("id") or record.get("patient_id") or ""),
        "patient_name": str(record.get("name") or record.get("patient_name") or ""),
        "treatment_date": str(record.get("treatment_date") or ""),
        "form_type": "09/BHYT",
        "insurance_code": str(record.get("insurance_code") or ""),
        "total_cost": total_cost,
        "status": "PROCESSED"
    }

def generate_09_bhyt_report(records, output_file="09_bhyt_report.json"):
    """
    Quy trình xử lý hồ sơ và sinh dữ liệu mẫu 09/BHYT.
    """
    log_ai(f"Bắt đầu quy trình tạo mẫu 09/BHYT cho {len(records)} bản ghi.")
    total_processed = 0
    results = []
    
    try:
        # Xử lý theo chunk để tiết kiệm RAM
        chunk_size = 1000
        for i in range(0, len(records), chunk_size):
            chunk = records[i:i + chunk_size]
            processed_batch = [process_09_bhyt_form(r) for r in chunk]
            results.extend(processed_batch)
            total_processed += len(processed_batch)
            del processed_batch
        
        with open(output_file, 'w', encoding='utf-8') as f:
            for item in results:
                f.write(json.dumps(item, ensure_ascii=False) + "\n")
        
        log_ai(f"Hoàn thành tạo mẫu 09/BHYT. Tổng cộng: {total_processed} hồ sơ.")
        return results
    except Exception as e:
        log_ai(f"Lỗi trong quá trình xử lý: {str(e)}")
        raise

class Mau09AiHandler(BaseHTTPRequestHandler):
    def _set_headers(self, status=200):
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()

    def do_GET(self):
        if self.path == "/health":
            self._set_headers(200)
            res = {"status": "ok", "service": "mau09_ai"}
            self.wfile.write(json.dumps(res).encode('utf-8'))
        else:
            self._set_headers(404)
            self.wfile.write(json.dumps({"error": "NOT_FOUND"}).encode('utf-8'))

    def do_POST(self):
        if self.path == "/api/process":
            try:
                content_len = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(content_len)
                data = json.loads(body.decode('utf-8')) if body else []
                if isinstance(data, dict):
                    data = [data]
                
                results = [process_09_bhyt_form(item) for item in data]
                self._set_headers(200)
                self.wfile.write(json.dumps({"status": "success", "count": len(results), "data": results}, ensure_ascii=False).encode('utf-8'))
            except Exception as e:
                log_ai(f"Lỗi API process: {str(e)}")
                self._set_headers(500)
                self.wfile.write(json.dumps({"error": "INTERNAL_SERVER_ERROR"}).encode('utf-8'))
        else:
            self._set_headers(404)
            self.wfile.write(json.dumps({"error": "NOT_FOUND"}).encode('utf-8'))

    def log_message(self, format, *args):
        # Format logger to use [AI] prefix
        log_ai(f"HTTP {args[0]} - {args[1]}")

def run_server(port=8081):
    server_address = ('127.0.0.1', port)
    httpd = HTTPServer(server_address, Mau09AiHandler)
    log_ai(f"Module AI Mau09 HTTP Service đang lắng nghe tại http://127.0.0.1:{port}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
        log_ai("Module AI Mau09 HTTP Service đã dừng.")

if __name__ == "__main__":
    port = 8081
    if len(sys.argv) > 1 and sys.argv[1].isdigit():
        port = int(sys.argv[1])
    run_server(port)
