@echo off
title Tat He Thong Mau09
cd /d "%~dp0"

echo ========================================================
echo   TAT HE THONG MAU 09 (Zero Hanging Tasks - Phan 1.5)
echo ========================================================
echo.

echo [1/4] Tat giao dien C# WPF UI...
taskkill /f /im Mau09.exe >nul 2>&1
taskkill /f /im Mau09Ui.exe >nul 2>&1

echo [2/4] Tat Go Engine Gateway...
taskkill /f /im mau09_engine.exe >nul 2>&1
taskkill /f /im mau09.exe >nul 2>&1

echo [3/4] Tat Python AI Service (app.py)...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { ($_.Name -match '^python') -and ($_.CommandLine -match 'app\.py') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1

wmic process where "CommandLine like '%%app.py%%'" call terminate >nul 2>&1

echo [4/4] Giai phong port he thong (8080, 8081)...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ports = @(8080, 8081); Get-NetTCPConnection -LocalPort $ports -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }" >nul 2>&1

echo.
echo ========================================================
echo Da don dep sach 100%% tien trinh he thong (Zero Hanging Tasks)!
echo ========================================================
ping 127.0.0.1 -n 2 >nul
exit
