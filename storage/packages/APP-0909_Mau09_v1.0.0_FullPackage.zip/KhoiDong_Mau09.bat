@echo off
title Khoi Dong Mau09 - He Thong BHYT
cd /d "%~dp0"

echo ========================================================
echo   HE THONG QUAN LY, DOI SOAT & KY SO BHYT MAU 09
echo   Kien truc: Antigravity Polyglot (C# + Go + Python + Rust)
echo ========================================================
echo.

:: 1. Khoi dong Python AI Service (Port 8081) neu co Python
if exist "mau09_ai\app.py" (
    echo [1/3] Khoi dong Python AI Service (Port 8081)...
    start /b "" python mau09_ai\app.py >nul 2>&1
)

:: 2. Khoi dong Go Engine Gateway (Port 8080)
if exist "mau09_engine.exe" (
    echo [2/3] Khoi dong Go Engine Gateway (Port 8080)...
    start /b "" mau09_engine.exe >nul 2>&1
) else if exist "mau09.exe" (
    echo [2/3] Khoi dong Go Engine Gateway (Port 8080)...
    start /b "" mau09.exe >nul 2>&1
)

:: Readiness Check: Kiem tra trang thai dich vu thay vi cho mu quang (Toi da 10 giay)
echo.
echo Dang kiem tra trang thai san sang (Readiness check - toi da 10 giay)...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$maxSeconds = 10; $start = [DateTime]::UtcNow; $needAi = (Test-Path 'mau09_ai\app.py'); $aiReady = -not $needAi; $engineReady = $false;" ^
    "while (([DateTime]::UtcNow - $start).TotalSeconds -lt $maxSeconds) {" ^
    "    if (-not $aiReady) {" ^
    "        try {" ^
    "            $res = Invoke-WebRequest -Uri 'http://127.0.0.1:8081/health' -UseBasicParsing -TimeoutSec 1;" ^
    "            if ($res.StatusCode -eq 200) {" ^
    "                $aiReady = $true;" ^
    "                Write-Host '  [READY] Python AI Service da san sang (Port 8081)' -ForegroundColor Green;" ^
    "            }" ^
    "        } catch {}" ^
    "    }" ^
    "    if (-not $engineReady) {" ^
    "        try {" ^
    "            $res = Invoke-WebRequest -Uri 'http://127.0.0.1:8080/health' -UseBasicParsing -TimeoutSec 1;" ^
    "            if ($res.StatusCode -eq 200) {" ^
    "                $engineReady = $true;" ^
    "                Write-Host '  [READY] Go Engine Gateway da san sang (Port 8080)' -ForegroundColor Green;" ^
    "            }" ^
    "        } catch {}" ^
    "    }" ^
    "    if ($aiReady -and $engineReady) {" ^
    "        Write-Host '  [THANH CONG] Backend da san sang hoat dong!' -ForegroundColor Cyan;" ^
    "        exit 0;" ^
    "    }" ^
    "    Start-Sleep -Milliseconds 800;" ^
    "}" ^
    "if (-not $aiReady) { Write-Host '  [CANH BAO] Python AI Service chua phan hoi sau 10s' -ForegroundColor Yellow; }" ^
    "if (-not $engineReady) { Write-Host '  [CANH BAO] Go Engine Gateway chua phan hoi sau 10s' -ForegroundColor Yellow; }"

:: 3. Khoi dong Giao dien C# WPF Chinh
echo.
echo [3/3] Khoi chay Giao dien Mau09 WPF...
start "" Mau09.exe

echo.
echo Da khoi dong he thong Mau09 thanh cong!
ping 127.0.0.1 -n 2 >nul
exit
