@echo off
chcp 65001 >nul
echo ========================================================
echo   CAI DAT TU DONG KHOI DONG CUNG WINDOWS - THONG BAO SO DU
echo ========================================================
echo.

set "EXE_PATH=%~dp0ThongBaoSoDu.exe"

if exist "%EXE_PATH%" (
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "ThongBaoSoDu" /t REG_SZ /d "\"%EXE_PATH%\"" /f >nul
    if %errorlevel% equ 0 (
        echo [OK] Da bat tu khoi dong cung Windows thanh cong!
        echo Duong dan: "%EXE_PATH%"
    ) else (
        echo [LOI] Khong the ghi vao Registry.
    )
) else (
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "ThongBaoSoDu" /t REG_SZ /d "pythonw \"%~dp0noti_app.pyw\"" /f >nul
    echo [OK] Da dang ky noti_app.pyw khoi dong cung Windows!
)

echo.
echo ========================================================
pause
