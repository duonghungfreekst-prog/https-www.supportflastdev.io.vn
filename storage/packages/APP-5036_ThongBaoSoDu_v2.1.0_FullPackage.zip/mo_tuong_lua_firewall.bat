@echo off
chcp 65001 >nul
echo ========================================================
echo   MO TUONG LUA WINDOWS CHO THONG BAO SO DU (LAN OFFLINE)
echo ========================================================
echo.

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [CANH BAO] Vui long chay file nay bang quyen Administrator!
    echo (Click chuot phai vao file nay chon 'Run as administrator')
    echo.
    pause
    exit /b
)

echo [1/3] Dang them rule cho TCP Port 8765 (HTTP API LAN)...
netsh advfirewall firewall delete rule name="ThongBaoSoDu_HTTP_LAN" >nul 2>&1
netsh advfirewall firewall add rule name="ThongBaoSoDu_HTTP_LAN" dir=in action=allow protocol=TCP localport=8765 profile=any description="Cho phep nhan thong bao so du tu Android qua LAN" >nul 2>&1
if %errorlevel% equ 0 (
    echo    -^> OK: TCP 8765 da duoc mo cho moi Profile mang!
) else (
    echo    -^> LOI mo port TCP 8765.
)

echo [2/3] Dang them rule cho UDP Port 8766 (UDP Discovery Broadcast)...
netsh advfirewall firewall delete rule name="ThongBaoSoDu_UDP_DISCOVERY" >nul 2>&1
netsh advfirewall firewall add rule name="ThongBaoSoDu_UDP_DISCOVERY" dir=in action=allow protocol=UDP localport=8766 profile=any description="Cho phep Android tu dong tim thay PC qua UDP Broadcast" >nul 2>&1
if %errorlevel% equ 0 (
    echo    -^> OK: UDP 8766 da duoc mo cho moi Profile mang!
) else (
    echo    -^> LOI mo port UDP 8766.
)

echo [3/3] Cho phep thuc thi ThongBaoSoDu.exe...
netsh advfirewall firewall delete rule name="ThongBaoSoDu_EXE" >nul 2>&1
set "EXE_PATH=%~dp0ThongBaoSoDu.exe"
if exist "%EXE_PATH%" (
    netsh advfirewall firewall add rule name="ThongBaoSoDu_EXE" dir=in action=allow program="%EXE_PATH%" profile=any >nul 2>&1
    echo    -^> OK: Da cho phep ThongBaoSoDu.exe
)

echo.
echo ========================================================
echo   HOAN TAT! Tuong lua Windows da duoc mo thong hoan toan.
echo   Dien thoai Android gio day co the tu dong tim thay PC!
echo ========================================================
pause
