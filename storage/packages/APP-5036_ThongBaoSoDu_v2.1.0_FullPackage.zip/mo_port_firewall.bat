@echo off
chcp 65001 >nul
echo ==============================================================
echo   CAU HINH TUONG LUA WINDOWS CHO APP THONG BAO SO DU (OFFLINE / HOTSPOT)
echo ==============================================================
echo.
echo Dang yeu cau quyen Administrator de mo Port 8765 (TCP) va 8766 (UDP)...

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [CANH BAO] Ban can chay file nay voi quyen Run as Administrator!
    echo Vui long chuot phai vao file va chon "Run as administrator".
    pause
    exit /b 1
)

echo Dang them quyen Tuong lua cho Port 8765 (HTTP API)...
netsh advfirewall firewall delete rule name="ThongBaoSoDu_HTTP_8765" >nul 2>&1
netsh advfirewall firewall add rule name="ThongBaoSoDu_HTTP_8765" dir=in action=allow protocol=TCP localport=8765 profile=any

echo Dang them quyen Tuong lua cho Port 8766 (UDP Discovery Hotspot)...
netsh advfirewall firewall delete rule name="ThongBaoSoDu_UDP_8766" >nul 2>&1
netsh advfirewall firewall add rule name="ThongBaoSoDu_UDP_8766" dir=in action=allow protocol=UDP localport=8766 profile=any

echo.
echo ==============================================================
echo   DA MO CONG TUONG LUA THANH CONG!
echo   - Port 8765 (TCP): Nhan thong bao bien dong so du
echo   - Port 8766 (UDP): Tu dong ket noi Hotspot giua Dien thoai va PC
echo ==============================================================
pause
