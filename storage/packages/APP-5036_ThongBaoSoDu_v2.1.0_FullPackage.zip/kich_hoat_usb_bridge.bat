@echo off
:: ============================================================================
:: KICH HOAT USB BRIDGE - THONG BAO SO DU
:: Offline 100% qua cap USB truc tiep (Do tre cuc thap < 1ms, khong can WiFi)
:: Co che: adb reverse tcp:8765 tcp:8765
:: ============================================================================
chcp 65001 >nul
title USB BRIDGE - THÔNG BÁO SỐ DƯ (OFFLINE ^< 1MS)
color 0A

:: ── 1. TIM KIEM ADB.EXE ──────────────────────────────────────────────────────
set "ADB="

if exist "%~dp0platform-tools\adb.exe" (
    set "ADB=%~dp0platform-tools\adb.exe"
    goto :ADB_FOUND
)
if exist "D:\platform-tools\adb.exe" (
    set "ADB=D:\platform-tools\adb.exe"
    goto :ADB_FOUND
)
if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" (
    set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
    goto :ADB_FOUND
)
if exist "C:\Users\Administrator\AppData\Local\Android\Sdk\platform-tools\adb.exe" (
    set "ADB=C:\Users\Administrator\AppData\Local\Android\Sdk\platform-tools\adb.exe"
    goto :ADB_FOUND
)
if exist "E:\AndroidEnv\sdk\platform-tools\adb.exe" (
    set "ADB=E:\AndroidEnv\sdk\platform-tools\adb.exe"
    goto :ADB_FOUND
)
if exist "E:\DevCache\android\Sdk\platform-tools\adb.exe" (
    set "ADB=E:\DevCache\android\Sdk\platform-tools\adb.exe"
    goto :ADB_FOUND
)

where adb >nul 2>&1
if %errorlevel% equ 0 (
    set "ADB=adb"
    goto :ADB_FOUND
)

:ADB_NOT_FOUND
color 0C
cls
echo ============================================================================
echo   [LỖI] KHÔNG TÌM THẤY TRÌNH ĐIỀU KHIỂN ADB (platform-tools\adb.exe)
echo ============================================================================
echo.
echo Không tìm thấy file adb.exe trên hệ thống.
echo Vui lòng giải nén Android platform-tools vào thư mục:
echo   %~dp0platform-tools\
echo hoặc thêm thư mục chứa adb.exe vào biến môi trường PATH.
echo.
echo ============================================================================
pause
exit /b 1

:ADB_FOUND
cls
echo ============================================================================
echo   CẦU NỐI TRUYỀN THÔNG BÁO QUA CÁP USB TRỰC TIẾP (OFFLINE 100%%)
echo   Độ trễ cực thấp ^< 1ms - Không cần WiFi - Không cần Internet
echo ============================================================================
echo [*] Trình điều khiển ADB: "%ADB%"
echo.

:: ── 2. KIEM TRA SERVER ADB VA THIET BI ─────────────────────────────────────────
echo [*] Đang khởi động ADB daemon...
"%ADB%" start-server >nul 2>&1

:SCAN_DEVICE
set "DEVICE_SERIAL="
set "DEVICE_STATE="
set "DEVICE_COUNT=0"

for /f "skip=1 tokens=1,2" %%A in ('"%ADB%" devices') do (
    if not "%%B"=="" (
        set "DEVICE_SERIAL=%%A"
        set "DEVICE_STATE=%%B"
        set /a DEVICE_COUNT+=1
    )
)

if "%DEVICE_COUNT%"=="0" (
    echo.
    echo ----------------------------------------------------------------------------
    echo [CHỜ KẾT NỐI USB] Chưa phát hiện điện thoại nào kết nối qua cáp USB!
    echo.
    echo  👉 Hướng dẫn thao tác trên điện thoại:
    echo     1. Cắm cáp USB nối điện thoại với máy tính PC.
    echo     2. Vào "Cài đặt" -^> "Tùy chọn cho nhà phát triển" (Developer Options).
    echo     3. Bật mục "Gỡ lỗi USB" (USB Debugging).
    echo.
    echo  Đang quét tìm thiết bị tự động mỗi 3 giây... (Nhấn Ctrl+C để thoát)
    echo ----------------------------------------------------------------------------
    timeout /t 3 /nobreak >nul
    goto :SCAN_DEVICE
)

if /i "%DEVICE_STATE%"=="unauthorized" (
    echo.
    echo ----------------------------------------------------------------------------
    echo [CẦN XÁC THỰC TRÊN ĐIỆN THOẠI]
    echo  Thiết bị: %DEVICE_SERIAL% đang ở trạng thái 'unauthorized'.
    echo.
    echo  👉 Hãy mở sáng màn hình điện thoại:
    echo     - Sẽ có hộp thoại "Cho phép gỡ lỗi USB từ máy tính này?"
    echo     - TÍCH VÀO: "Luôn cho phép từ máy tính này" (Always allow)
    echo     - BẤM: "Cho phép" (Allow)
    echo.
    echo  Đang chờ bạn cấp quyền...
    echo ----------------------------------------------------------------------------
    timeout /t 3 /nobreak >nul
    goto :SCAN_DEVICE
)

if not /i "%DEVICE_STATE%"=="device" (
    echo.
    echo [THÔNG BÁO] Thiết bị %DEVICE_SERIAL% đang ở trạng thái: %DEVICE_STATE%
    echo Đang chờ thiết bị sẵn sàng...
    timeout /t 3 /nobreak >nul
    goto :SCAN_DEVICE
)

:: ── 3. THIET BI DA SAN SANG - LAY THONG TIN ──────────────────────────────────
set "DEVICE_MODEL=Android Device"
for /f "delims=" %%M in ('"%ADB%" -s %DEVICE_SERIAL% shell getprop ro.product.model 2^>nul') do set "DEVICE_MODEL=%%M"

set "DEVICE_OS=Unknown"
for /f "delims=" %%V in ('"%ADB%" -s %DEVICE_SERIAL% shell getprop ro.build.version.release 2^>nul') do set "DEVICE_OS=%%V"

echo.
echo ============================================================================
echo   [ĐÃ KẾT NỐI] Phát hiện điện thoại thành công!
echo   - Thiết bị: %DEVICE_MODEL%
echo   - Serial  : %DEVICE_SERIAL%
echo   - Android : Version %DEVICE_OS%
echo ============================================================================
echo.

:: ── 4. KICH HOAT ADB REVERSE PORT 8765 ───────────────────────────────────────
echo [*] Đang thiết lập cầu nối chuyển tiếp cổng (ADB Reverse tcp:8765 tcp:8765)...
"%ADB%" -s %DEVICE_SERIAL% reverse tcp:8765 tcp:8765

if %errorlevel% neq 0 (
    echo.
    echo [LỖI] Không thể kích hoạt reverse port 8765!
    echo Vui lòng rút cáp cắm lại và thử lại.
    pause
    goto :SCAN_DEVICE
)

echo.
echo ============================================================================
echo   🟢 KÍCH HOẠT THÀNH CÔNG USB BRIDGE REVERSE PORT 8765!
echo ============================================================================
echo   Điện thoại (127.0.0.1:8765)  ==== Cáp USB (<1ms) ====>  PC (127.0.0.1:8765)
echo.
echo   [*] Danh sách cổng reverse đang hoạt động:
"%ADB%" -s %DEVICE_SERIAL% reverse --list
echo ============================================================================
echo.

:: ── 5. KIEM TRA VA KHOI DONG APP PC NEU CHUA CHAY ───────────────────────────
netstat -ano | findstr /R /C:":8765 .*LISTENING" >nul 2>&1
if %errorlevel% neq 0 (
    echo [CHÚ Ý] Ứng dụng Thông Báo Số Dư chưa chạy trên PC (cổng 8765 chưa mở).
    echo [*] Đang tự động khởi động ứng dụng PC...
    if exist "%~dp0ThongBaoSoDu.exe" (
        start "" "%~dp0ThongBaoSoDu.exe"
        echo [OK] Đã khởi động ThongBaoSoDu.exe
    ) else if exist "%~dp0noti_app.pyw" (
        start "" pythonw "%~dp0noti_app.pyw"
        echo [OK] Đã khởi động noti_app.pyw bằng pythonw
    )
    timeout /t 2 /nobreak >nul
) else (
    echo [OK] Ứng dụng PC Thông Báo Số Dư đã sẵn sàng và đang lắng nghe tại cổng 8765.
)

:: ── 6. TU DONG CAU HINH IP 127.0.0.1 VAO APP ANDROID ─────────────────────────
echo.
echo [*] Kiểm tra cấu hình IP trên ứng dụng điện thoại...
"%ADB%" -s %DEVICE_SERIAL% shell "run-as com.example.appthongbaosodu mkdir -p /data/data/com.example.appthongbaosodu/shared_prefs 2>/dev/null" >nul 2>&1
"%ADB%" -s %DEVICE_SERIAL% shell "run-as com.example.appthongbaosodu sh -c 'echo \"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\n<map>\n    <string name=\\\"pc_ip\\\">127.0.0.1</string>\n</map>\" > /data/data/com.example.appthongbaosodu/shared_prefs/AppPrefs.xml' 2>/dev/null" >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Đã tự động thiết lập IP máy tính = 127.0.0.1 trong ứng dụng điện thoại!
) else (
    echo [LƯU Ý] Mở app 'Thông Báo Số Dư' trên điện thoại, tại ô 'Kết nối Máy tính':
    echo         Nhập IP là: 127.0.0.1 rồi nhấn 'Lưu' (nếu chưa nhập).
)
echo.

:: ── 7. MENU TUY CHON VA DIEU KHIEN ───────────────────────────────────────────
:MENU
echo ----------------------------------------------------------------------------
echo CHỌN CHỨC NĂNG:
echo   [1] Bật chế độ Tự Động Giám Sát ^& Tái Kết Nối (Watchdog Auto-Reconnect)
echo   [2] Bắn thông báo TEST thử nghiệm từ điện thoại qua USB (^< 1ms)
echo   [3] Xem danh sách port reverse hiện tại
echo   [4] Mở giao diện Dashboard trên trình duyệt PC
echo   [5] Kích hoạt lại cầu nối USB
echo   [0] Thoát
echo ----------------------------------------------------------------------------
set /p "CHOICE=Nhập lựa chọn của bạn [Mặc định 1]: "
if "%CHOICE%"=="" set "CHOICE=1"

if "%CHOICE%"=="1" goto :WATCHDOG
if "%CHOICE%"=="2" goto :TEST_USB
if "%CHOICE%"=="3" goto :LIST_REVERSE
if "%CHOICE%"=="4" goto :OPEN_DASHBOARD
if "%CHOICE%"=="5" goto :SCAN_DEVICE
if "%CHOICE%"=="0" goto :EXIT_SCRIPT

echo [!] Lựa chọn không hợp lệ, vui lòng chọn lại.
goto :MENU

:: ── CHUC NANG 2: TEST GUI THONG BAO QUA USB ──────────────────────────────────
:TEST_USB
cls
echo ============================================================================
echo   ĐANG GỬI THỬ THÔNG BÁO TEST TỪ ĐIỆN THOẠI SANG PC QUA CÁP USB...
echo ============================================================================
echo URL đích: http://127.0.0.1:8765/notify
echo.

set "TEST_PAYLOAD={\"speech\":\"Kiem tra ket noi USB thanh cong! Do tre duoi 1 mili giay\",\"bank\":\"USB_DIRECT\",\"raw\":\"So tien: 100000\nNoi dung: Test ket noi cap USB truc tiep\"}"

"%ADB%" -s %DEVICE_SERIAL% shell "which curl >/dev/null 2>&1"
if %errorlevel% equ 0 (
    "%ADB%" -s %DEVICE_SERIAL% shell "curl -s -X POST http://127.0.0.1:8765/notify -H 'Content-Type: application/json; charset=utf-8' -d '{\"speech\":\"Kiem tra ket noi USB thanh cong! Do tre duoi 1 mili giay\",\"bank\":\"USB_DIRECT\",\"raw\":\"So tien: 100000\nNoi dung: Test ket noi cap USB truc tiep\"}'"
    echo.
    echo [*] Đã gửi lệnh curl từ điện thoại sang http://127.0.0.1:8765/notify!
) else (
    :: Fallback dung powershell tren PC gui toi 127.0.0.1:8765 de kiem tra server
    powershell -NoProfile -Command "try { $res = Invoke-RestMethod -Uri 'http://127.0.0.1:8765/notify' -Method Post -ContentType 'application/json; charset=utf-8' -Body '%TEST_PAYLOAD%'; Write-Host '[OK] Server PC da phan hoi:' ($res | ConvertTo-Json -Compress) } catch { Write-Host '[LOI]' $_.Exception.Message }"
)

echo.
echo 👉 Hãy quan sát góc dưới bên phải màn hình PC xem popup có hiện lên không!
echo ============================================================================
pause
goto :MENU

:: ── CHUC NANG 3: XEM DANH SACH REVERSE ────────────────────────────────────────
:LIST_REVERSE
cls
echo ============================================================================
echo   DANH SÁCH CÁC CỔNG ADB REVERSE HIỆN TẠI
echo ============================================================================
"%ADB%" -s %DEVICE_SERIAL% reverse --list
echo.
pause
goto :MENU

:: ── CHUC NANG 4: MO DASHBOARD TRINH DUYET ────────────────────────────────────
:OPEN_DASHBOARD
start http://127.0.0.1:8765/
goto :MENU

:: ── CHUC NANG 1: CHE DO GIAM SAT TU DONG (WATCHDOG AUTO-RECONNECT) ───────────
:WATCHDOG
cls
echo ============================================================================
echo   🟢 CHẾ ĐỘ GIÁM SÁT TỰ ĐỘNG (WATCHDOG AUTO-RECONNECT ĐANG HOẠT ĐỘNG)
echo ============================================================================
echo   Thiết bị đang kết nối: %DEVICE_MODEL% (%DEVICE_SERIAL%)
echo   Đường truyền USB Bridge : tcp:8765 ^<-^> tcp:8765 (Độ trễ ^< 1ms)
echo.
echo   [*] Tính năng tự động:
echo       - Nếu bạn rút cáp USB ra: Hệ thống sẽ chuyển sang chế độ chờ.
echo       - Ngay khi cắm lại cáp: Tự động kích hoạt lại bridge ngay lập tức!
echo.
echo   [!] Nhấn phím M để quay lại Menu, hoặc nhấn Ctrl+C để đóng cửa sổ.
echo ============================================================================
echo.

:WATCHDOG_LOOP
"%ADB%" -s %DEVICE_SERIAL% get-state >nul 2>&1
if %errorlevel% neq 0 (
    color 0E
    echo.
    echo [%TIME:~0,8%] ⚠️ MẤT KẾT NỐI CÁP USB!
    echo         Đang chờ cắm lại cáp USB...
    
    :WATCHDOG_RETRY
    timeout /t 2 /nobreak >nul
    for /f "skip=1 tokens=1,2" %%A in ('"%ADB%" devices') do (
        if /i "%%B"=="device" (
            set "DEVICE_SERIAL=%%A"
            color 0A
            echo.
            echo [%TIME:~0,8%] 🟢 PHÁT HIỆN THIẾT BỊ MỚI (%DEVICE_SERIAL%)!
            echo         Đang tự động tái kích hoạt USB Bridge port 8765...
            "%ADB%" -s %%A reverse tcp:8765 tcp:8765
            if %errorlevel% equ 0 (
                echo [%TIME:~0,8%] ✅ ĐÃ TÁI KẾT NỐI THÀNH CÔNG! Độ trễ ^< 1ms.
            )
            goto :WATCHDOG_LOOP
        )
    )
    goto :WATCHDOG_RETRY
)

:: Kiem tra pham vi reverse dinh ky
"%ADB%" -s %DEVICE_SERIAL% reverse --list | findstr "8765" >nul 2>&1
if %errorlevel% neq 0 (
    echo [%TIME:~0,8%] [*] Đang làm mới cấu hình reverse port 8765...
    "%ADB%" -s %DEVICE_SERIAL% reverse tcp:8765 tcp:8765 >nul 2>&1
)

timeout /t 3 /nobreak >nul
goto :WATCHDOG_LOOP

:EXIT_SCRIPT
echo.
echo Tạm biệt! USB Bridge vẫn duy trì hoạt động cho đến khi bạn rút cáp.
timeout /t 2 /nobreak >nul
exit /b 0
