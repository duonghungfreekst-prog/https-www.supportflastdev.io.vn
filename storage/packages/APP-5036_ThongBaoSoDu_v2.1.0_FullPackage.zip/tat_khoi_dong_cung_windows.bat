@echo off
chcp 65001 >nul
echo ========================================================
echo   TAT TU DONG KHOI DONG CUNG WINDOWS - THONG BAO SO DU
echo ========================================================
echo.

reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "ThongBaoSoDu" /f >nul 2>&1
echo [OK] Da tat tu khoi dong cung Windows thanh cong!
echo.
echo ========================================================
pause
