# 📘 CẨM NANG HƯỚNG DẪN SỬ DỤNG: THÔNG BÁO SỐ DƯ & USB BRIDGE v2.1.0

> **Giải pháp truyền biến động số dư ngân hàng từ điện thoại Android sang máy tính Windows với độ trễ < 1ms, hoạt động hoàn toàn Offline 100% qua cáp USB và mạng Wi-Fi nội bộ.**

---

## 📑 MỤC LỤC
1. [Chương 1: Tổng Quan & Kiến Trúc USB Bridge](#chương-1-tổng-quan--kiến-trúc-usb-bridge)
2. [Chương 2: Cài Đặt Ứng Dụng Android (Notification Forwarder)](#chương-2-cài-đặt-ứng-dụng-android-notification-forwarder)
3. [Chương 3: Bật Chế Độ Gỡ Lỗi USB (USB Debugging)](#chương-3-bật-chế-độ-gỡ-lỗi-usb-usb-debugging)
4. [Chương 4: Cài Đặt & Khởi Chạy Trên Máy Tính Windows](#chương-4-cài-đặt--khởi-chạy-trên-máy-tính-windows)
5. [Chương 5: Kích Hoạt Kết Nối USB Bridge 1-Click](#chương-5-kích-hoạt-kết-nối-usb-bridge-1-click)
6. [Chương 6: Tùy Chỉnh Giọng Đọc Text-To-Speech (TTS)](#chương-6-tùy-chỉnh-giọng-đọc-text-to-speech-tts)
7. [Chương 7: Chế Độ Kết Nối Wi-Fi LAN & Bảo Mật API Key](#chương-7-chế-độ-kết-nối-wi-fi-lan--bảo-mật-api-key)
8. [Chương 8: Xử Lý Sự Cố Thường Gặp (Troubleshooting)](#chương-8-xử-lý-sự-cố-thường-gặp-troubleshooting)

---

## Chương 1: Tổng Quan & Kiến Trúc USB Bridge

### 1.1 Điểm đột phá của USB Bridge
- **Offline 100%**: Không phụ thuộc vào modem Wi-Fi hay đường truyền Internet. Khi mạng Wi-Fi bị nghẽn hoặc rớt mạng, giao dịch vẫn báo về máy tính tức thì.
- **Độ trễ cực thấp (< 1ms)**: Tốc độ truyền tải trực tiếp trên thanh ghi phần cứng USB bus thay vì truyền sóng không dây (20ms - 200ms).
- **Cấp nguồn 24/7**: Cáp USB vừa truyền tín hiệu thông báo, vừa sạc pin liên tục cho điện thoại bán hàng/thu ngân.

### 1.2 Mô hình luồng dữ liệu (Data Pipeline)
```text
[App Ngân Hàng / SMS]
        │
        ▼ (Phát thông báo)
[Điện thoại Android: App Thông Báo Số Dư]
        │ (Bắt biến động & phân tích số tiền)
        ▼
   POST http://127.0.0.1:8765/notify
        │
        ▼ (ADB Reverse Port Forwarding)
 ═══ CÁP USB KẾT NỐI (Độ trễ < 0.5ms) ═══
        │
        ▼
[Máy tính Windows: ThongBaoSoDu.exe]
        ├─► Hiện Popup thông báo góc màn hình
        ├─► Đọc to bằng giọng nói Tiếng Việt (TTS)
        └─► Ghi lịch sử giao dịch vào history.json
```

---

## Chương 2: Cài Đặt Ứng Dụng Android (Notification Forwarder)

1. Sao chép tệp `ThongBaoSoDu_Android.apk` (hoặc `app-debug.apk`) vào điện thoại Android.
2. Mở trình quản lý tệp trên điện thoại, bấm vào file `.apk` để tiến hành cài đặt.
3. Nếu điện thoại hiển thị cảnh báo "Cài đặt ứng dụng từ nguồn không xác định", chọn **Cho phép từ nguồn này**.
4. **Cấp quyền truy cập thông báo (Bắt buộc)**:
   - Mở ứng dụng lần đầu tiên, bấm **Cấp quyền thông báo**.
   - Hệ thống chuyển vào màn hình **Quyền truy cập thông báo** (Notification Access).
   - Tìm ứng dụng **Thông Báo Số Dư** và gạt công tắc sang **BẬT (Cho phép)**.
5. **Cấu hình máy chủ nhận**:
   - Nếu dùng USB Bridge: Giữ nguyên địa chỉ mặc định `http://127.0.0.1:8765`.
   - Nếu dùng Wi-Fi: Nhập địa chỉ IP máy tính hiển thị trên giao diện app PC (Ví dụ: `http://192.168.1.15:8765`).

---

## Chương 3: Bật Chế Độ Gỡ Lỗi USB (USB Debugging)

Để cáp USB truyền được dữ liệu ADB Reverse, bạn cần bật gỡ lỗi USB trên điện thoại một lần duy nhất:

1. Vào **Cài đặt (Settings)** -> **Thông tin điện thoại (About phone)**.
2. Tìm dòng **Số bản dựng (Build number)** và chạm liên tục **7 lần** cho đến khi có thông báo *"Bạn đã là nhà phát triển"*.
3. Quay lại menu Cài đặt -> Vào **Hệ thống** -> **Tùy chọn nhà phát triển (Developer options)**.
4. Tìm và kích hoạt mục **Gỡ lỗi USB (USB debugging)**.
5. Cắm cáp USB nối điện thoại vào máy tính Windows. Trên màn hình điện thoại sẽ hiện hộp thoại:
   - Tích chọn: *"Luôn cho phép từ máy tính này"* (Always allow from this computer).
   - Bấm **Cho phép (OK)**.

---

## Chương 4: Cài Đặt & Khởi Chạy Trên Máy Tính Windows

1. Giải nén thư mục gói ứng dụng `ThongBaoSoDu_v2.1.0_FullPackage.zip`.
2. Khởi chạy file `ThongBaoSoDu.exe`.
3. Ứng dụng sẽ xuất hiện dưới khay hệ thống (System Tray) với biểu tượng chiếc chuông xanh.
4. **Cài đặt tự khởi động cùng Windows**:
   - Chạy file `cai_dat_khoi_dong_cung_windows.bat`.
   - Từ nay, mỗi khi mở máy tính, phần mềm sẽ tự động chạy ngầm sẵn sàng đón nhận thông báo.

---

## Chương 5: Kích Hoạt Kết Nối USB Bridge 1-Click

1. Cắm cáp USB kết nối điện thoại và máy tính.
2. Bấm đúp chuột vào file `kich_hoat_usb_bridge.bat`.
3. Script sẽ tự động:
   - Kiểm tra thiết bị kết nối qua lệnh `adb devices`.
   - Thiết lập đường hầm đảo chiều: `adb reverse tcp:8765 tcp:8765`.
   - Kiểm tra thông tuyến tín hiệu tới cổng `8765`.
4. Màn hình báo màu xanh: **[THÀNH CÔNG] KẾT NỐI USB BRIDGE ĐÃ SẴN SÀNG!**
5. Bạn có thể bấm nút **BẮN TEST THỬ** trên điện thoại để kiểm tra âm thanh và popup trên máy tính.

---

## Chương 6: Tùy Chỉnh Giọng Đọc Text-To-Speech (TTS)

Phần mềm tích hợp công nghệ tổng hợp giọng nói Windows SAPI5 / pyttsx3:
- **Ngôn ngữ**: Đọc tiếng Việt chuẩn xác từng mệnh giá tiền (Ví dụ: *+500,000 VND* -> *"Cộng năm trăm nghìn đồng"*).
- **Đọc nội dung chuyển khoản**: Tự động lọc và đọc tên người gửi kèm lời nhắn thanh toán.
- **Tùy chỉnh tốc độ**: Mở cấu hình để tăng/giảm tốc độ đọc theo nhu cầu của quầy thanh toán.

---

## Chương 7: Chế Độ Kết Nối Wi-Fi LAN & Bảo Mật API Key

1. **Chế độ Wi-Fi LAN**:
   - Khi điện thoại và máy tính kết nối chung mạng Wi-Fi, máy tính sẽ hiển thị địa chỉ IP nội bộ (ví dụ: `192.168.1.50`).
   - Mở file `mo_tuong_lua_firewall.bat` bằng quyền Run as Administrator để mở cổng 8765 trên Windows Firewall.
2. **Bảo mật API Key (`api_key.txt`)**:
   - Để ngăn chặn thiết bị lạ bắn tin nhắn giả mạo, bật `"require_api_key": true` trong `config.json`.
   - Sao chép mã trong `api_key.txt` vào ô API Key trên ứng dụng điện thoại.
   - Giao thức hỗ trợ kiểm tra mã băm SHA-256 và Idempotency Key chống trùng lặp dữ liệu.

---

## Chương 8: Xử Lý Sự Cố Thường Gặp (Troubleshooting)

- **Hỏi: Lệnh `kich_hoat_usb_bridge.bat` báo "device unauthorized"?**
  - *Đáp*: Mở màn hình điện thoại, kiểm tra hộp thoại hỏi quyền gỡ lỗi USB, tích chọn *"Luôn cho phép"* và bấm OK.
- **Hỏi: Điện thoại không bắt được thông báo ngân hàng?**
  - *Đáp*: Đảm bảo đã cấp quyền "Truy cập thông báo" cho ứng dụng Android và tắt chế độ "Tiết kiệm pin" đối với ứng dụng để Android không ngắt tiến trình ngầm.
- **Hỏi: Máy tính không phát âm thanh giọng đọc?**
  - *Đáp*: Kiểm tra loa máy tính và đảm bảo gói ngôn ngữ Tiếng Việt (hoặc Microsoft An / Mai) đã được bật trong Windows Settings -> Speech.

---
*Bản quyền phát hành © 2026 SupportFlast App Hub (https://supportflastdev.io.vn)*
